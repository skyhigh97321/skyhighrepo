/**
 * Created by colinlancaster on 6/15/15.
 */
$(function() {
    $("a[href=#menuExpand]").click(function(e) {
        $(".menu").toggleClass("menuOpen");
        e.preventDefault();
    });
});