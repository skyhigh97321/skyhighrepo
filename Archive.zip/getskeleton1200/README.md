GetSkeleton1200
===============

Base on Get Skeleton Grid : http://getskeleton.com/

16 columns /
55px columns width /
10px gutter

I added style for 1200px width. So you can design for wide screen. If the screen is less than 1200px, it's take the original size. (960px).

Simple!

#####Available on Bower
```
bower install getskeleton1200
```

Photoshop Action
===============

The .atn create the guides.

1. Create your psd in 1200px. 
2. Run the .atn
3. Resize your psd if you want. (ex: 1400px)

.SCSS
===============

I created the sass file for people who code in sass. You only need to import the file in your .scss. (ex: @import '_skeleton1200';)

####If you want to switch between both grid, check this out: https://github.com/theresponsiveness/GetSkeleton1200-or-960

#####Drop me a line! twitter: @_polikin
