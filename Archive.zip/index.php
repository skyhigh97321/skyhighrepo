<?php
require 'vendor/autoload.php';
date_default_timezone_set('America/New_York');

// Creates a new app
$app = new \Slim\Slim( array(
    'view' => new \Slim\Views\Twig() // sets the view class to a new view class
));

// Create a new view
$view = $app->view();

// turn on debug
$view->parserOptions = array (
    'debug' => true
);

$view->parserExtensions = array(
    new \Slim\Views\TwigExtension()
);

// Gets home
$app->get('/', function() use($app){
    $app->render('main.twig');
});

// Gets contact
$app->get('/contact', function() use($app){
    $app->render('contact.twig');
});

// Gets about
$app->get('/about', function() use($app){
    $app->render('about.twig');
});

// Gets consulting
$app->get('/consulting', function() use($app){
    $app->render('consulting.twig');
});

// Gets service area
$app->get('/service_area', function() use($app){
    $app->render('service_area.twig');
});

// Gets products
$app->get('/products', function() use($app){
    $app->render('products.twig');
});

// Runs the new app
$app->run();
